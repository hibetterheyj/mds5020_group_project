Demo of Data Mining Pipeline Development, Deployment and Testing

1. Develop a data mining pipeline for topic classification, save it for deployment, and test the saved model locally.
	Step 1: Create and save the pipeline
		- Develop your topic classification (or sentiment analysis) pipelines following the script at "/docker_demo/app/model/topic_model_dev.py".
		- Include data preprocessing, feature extraction, and model training.
		- Save the trained model using a preferred method (e.g., joblib or pickle).
		- **Record and submit** the 5-fold cross-validation performance (weighted F1 score) on the training data.
	Step 2: Reload and test the saved pipeline
		- Use the script in "/docker_demo/app/model/topic_model_test.py" to load and test your saved model locally.

2. Load the saved pipeline and deploy it as an API service, then test the API locally.
	Step 1: Install Python and required packages
		- Create a virtual environment with Python 3.13 (or consistent with your development environment).
		- Install required packages from "/docker_demo/requirements.txt".
	Step 2: Navigate to the application path
		- Change your directory to "/docker_demo/app".
	Step 3: Run the API service
		- Execute "$python main.py" to start the API service.
	Step 4: Test the API service locally
		- Use the script in "/docker_demo/app/test/api_test.py" to test the API service on port 5724 with "url_local".

3. Build and run a Docker image for your pipeline and working environment.
	Step 1: Build the Docker image under the folder "/docker_demo"
		- Run "$docker build -f Dockerfile_python ." to build the Docker image.
	Step 2: Run and test the Docker container
		- Use "$docker run -d -p 9000:5724 --memory=900m [IMAGE ID]" to run the Docker container.
	Step 3: Test the API service within the Docker container
		- Test the API service supported by the docker built by you using "/docker_demo/app/test/api_test.py" on port 9000 with "url_docker".

4. Upload the Docker image to your public ACR account.
	Step 1: Create your public ACR account and upload/push the image following the instructions in the webpages under your ACR account
	Step 2: **Record and submit** the URL of your Docker image in ACR.

5. Pull and Test the Docker Image from your public ACR repository.
	Step 1: Pull the Docker image with the above URL from your ACR account.
	Step 2: Test the API service supported by the docker pulled by you using "/docker_demo/app/test/api_test.py" on port 9000 with "url_docker".