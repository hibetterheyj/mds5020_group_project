# -*- coding: utf-8 -*-
"""
Created on Wed Nov 13 19:11:14 2024

@author: Neal
"""

clf = None